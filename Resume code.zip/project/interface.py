import tkinter as tk
from tkinter import filedialog
import pickle
from pdf2docx import Converter
import os
import re
import nltk
import spacy
import string
import textract
import pandas as pd
import seaborn as sns
from matplotlib import pylab
from matplotlib import pyplot as plt
import nltk
from nltk.tokenize import RegexpTokenizer
from nltk.corpus import stopwords
import heapq
import re
import pickle 
def open_file_dialog():
    global path
    file_path = filedialog.askopenfilename(filetypes=[("Word Documents", "*.docx"), ("PDF Files", "*.pdf")])
    if file_path:
        path=file_path
        if path.endswith(".pdf"):
            temp_path=file_path[0:len(file_path)-4] +".docx"
            cv=Converter(file_path)
            cv.convert(temp_path,start=0,end=None)
            cv.close()
            path=temp_path
        pdct()

def pdct():
    global path
    global h
    global tmp
    name=path.split("/")[-1]
    s=textract.process(path).decode('utf-8')
    file_path=[(textract.process(path)).decode('utf-8')]
    year=0
    pattern = r'\b(\w+)\s+year?s\b'
    p2=r'\b\d{4}-\d{4}\b'


    matches1 = re.findall(pattern, s)
    matches2=re.findall(p2,s)
    if matches1:
        year=int(matches1[0])
    elif matches2:
        x,y=matches2[0].split("-")
        year=int(y)-int(x)
    


    resume_data = pd.DataFrame(data = file_path , columns = ['Raw_Details'])
    #resume_data['Resume_Details'] = resume_data.Raw_Details.apply(lambda x: preprocess(x))
    resume_data['Resume_Details'] = resume_data.Raw_Details
    resume_data.drop(['Raw_Details'], axis = 1, inplace = True)

    x=resume_data['Resume_Details']
    x=vector.transform(x)
    pred=modelDT.predict(x)[0]

    f=open("data.pkl","rb")
    d=pickle.load(f)
    heap=[]
    if pred in d:
        heap=d[pred]
    vis={}
    if [-year,name] not in heap: 
        heapq.heappush(heap,[-year,name])
    print(heap)
    d[pred]=heap
    f.close()
    f=open("data.pkl","wb")
    pickle.dump(d,f)
    f.close()
    h=d[pred]
    label.config(text=pred)
    for i in range(len(d[pred])):
        label1=tk.Label(root,text=h[0][1] +"- %s years"%(-h[0][0]))
        heapq.heappop(h)
        label1.place(x=700,y=300+50*i)
        tmp.append(label1)
    
    
def clr():
    global tmp
    for i in tmp:
        i.destroy()
    tmp=[]
    


# Create the main window
path=""
root = tk.Tk()
root.title("File Upload Example")

h=[]
tmp=[]
f=open("modelDT.pkl","rb")
modelDT=pickle.load(f)

g=open("vector.pkl","rb")
vector=pickle.load(g)
f.close()
g.close()

# Create and pack a button for file selection
upload_button = tk.Button(root, text="Upload File", command=open_file_dialog)
upload_button.pack(pady=20)

clr_button=tk.Button(root, text="Clear", command=clr)
clr_button.pack(pady=40)
label=tk.Label(root,text="")
label.place(x=700,y=250)

root.mainloop()